package Theatre;
public class Ticket {
    private final int count;
    private final int row;
    private final int seat;
    private double price;

    private final Person person;

    public Ticket(int row, int seat, double price, Person person, int count) {
        this.row = row;
        this.seat = seat;
        this.price = price;
        this.person = person;
        this.count = count;
    }

    public int getRow() {
        return row;
    }

    public int getSeat() {
        return seat;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Person getPerson() {
        return person;
    }

    /*
        Because my prices drop when more tickets are purchased, I utilize a count to adjust ticket prices when
        a ticket is cancelled.
         */
    public int getCount() {
        return count;
    }
    public void print() {
        System.out.println("Name: " + person.getName());
        System.out.println("Surname: " + person.getSurname());
        System.out.println("Email: " + person.getEmail());
        System.out.println("Row: " + row);
        System.out.println("Seat: " + seat);
        System.out.println("Price: $" + price);
    }
}

/*
This is the Ticket class which creates objects that represent tickets for a performance.
It contains fields for the row, seat, price and Person associated with the ticket.
It also contains methods for retrieving, setting and printing the fields.
*/