package Theatre;
import java.util.*;
import java.io.*;
public class Theatre {
    public static void main(String[]args) {
        System.out.println("WELCOME TO THE NEW THEATRE");
        // Creating 3 arrays for each row
        int[] row1 = new int[12];
        int[] row2 = new int[16];
        int[] row3 = new int[20];
        // An arraylist to store ticket information of each person
        ArrayList<Ticket> tickets = new ArrayList<>();
        // All elements in the array are assigned a value of 0 to indicate that the seat is available.
        for (int i = 0; i < 12; i++) {
            row1[i] = 0;
        }
        for (int i = 0; i < 16; i++) {
            row2[i] = 0;
        }
        for (int i = 0; i < 20; i++) {
            row3[i] = 0;
        }

        // this variable used for use to be able to buy or cancel another ticket before going back to main menu
        char decision;
        int option;
        // Using exception handling to check invalid inputs
        while (true){
            try { Scanner input = new Scanner(System.in);
                do { // Main menu for the user to select an option to perform
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    System.out.println("Please select an option:");
                    System.out.println("1) Buy a ticket");
                    System.out.println("2) Print seating area");
                    System.out.println("3) Cancel a ticket");
                    System.out.println("4) List available seats");
                    System.out.println("5) Save to file");
                    System.out.println("6) Load from file");
                    System.out.println("7) Print ticket information and total price");
                    System.out.println("8) Sort tickets by price");
                    System.out.println("0) Quit");
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    System.out.print("Enter Option: ");
                    option = input.nextInt();
                    System.out.println();

                    // Switch case runs based on users entered option
                    switch (option) {
                        case 0 -> System.exit(0);
                        case 1 -> // Buy a ticket
                        {decision = 'y';
                            while (decision != 'q') {
                                if (decision == 'y') {
                                    print_seating_area(row1, row2, row3);
                                    buy_ticket(row1, row2, row3, tickets);
                                    // calling print_seating method for user to view bought ticket
                                    System.out.print("Would you want to buy another ticket?\nEnter 'y' to continue or 'q' " +
                                            "to quit and go back to the main menu : ");
                                } else {
                                    System.out.print("Please enter 'y' or q : ");
                                }
                                decision = input.next().charAt(0);
                                System.out.println();
                            }
                        }
                        case 2 -> // Print seating area
                                print_seating_area(row1, row2, row3);
                        case 3 -> // Cancel a ticket
                            { decision = 'y';
                            while (decision != 'q') {
                                if (decision == 'y') {
                                    cancel_ticket(row1, row2, row3, tickets);
                                    System.out.print("Would you want to cancel another ticket?\nEnter 'y' to continue or " +
                                            "'q' to quit and go back to the main menu : ");
                                } else {
                                    System.out.print("Please enter 'y' or q : ");
                                }
                                decision = input.next().charAt(0);
                                System.out.println();
                            }
                        }
                        case 4 -> // List available seats
                                show_available(row1, row2, row3);
                        case 5 -> // Save to file
                                saveToFile(row1, row2, row3);
                        case 6 -> // Load from file
                                loadFromFile(row1,row2,row3);
                        case 7 ->// Print ticket information and total price
                                show_tickets_info(tickets);
                        case 8 -> // Sort tickets by price
                                sort_tickets(tickets);
                        default -> System.out.println("\nPlease enter valid option!");
                    }
                } while (true);
            } catch (InputMismatchException e) {
                System.out.println("\nInvalid input! Please enter a valid option.");
            }
        }
    }
    public static void buy_ticket(int[] row1, int[] row2, int[] row3, ArrayList<Ticket> tickets) {
        // Using exception handling to check invalid inputs
        while(true) {
            try { // Getting a person's information
                int availableNum = 48;
                int[][] Rows = {row1, row2, row3};
                Scanner input = new Scanner(System.in);
                System.out.print("Enter Name: ");
                String name = input.next();
                System.out.print("Enter Surname: ");
                String surname = input.next();
                System.out.print("Enter Email: ");
                String email = input.next();
                System.out.println("""
                        \nGet 1 ticket for $20, 2 tickets for $15 each,or more of tickets just $10 each.
                        Don't miss out,save your money and get your tickets now!
                        """);
                /// According to the number tickets the user enters the loop run and buy tickets
                while (true) {
                    for (int[] row : Rows) {
                        for (int i : row) {
                            if (i == 1) availableNum -= 1;
                        }
                    }
                    System.out.print("Number of tickets: ");
                    int numTickets = input.nextInt();
                    // As long as there are available tickets the loop will run
                    if (numTickets <= availableNum && numTickets > 0) {
                        // Each person can buy multiple tickets and their information will come under the ticket information
                        Person person = new Person(name, surname, email);
                        for (int i = 0; i < numTickets; i++) {
                            System.out.print("Enter the row number: ");
                            int rowNum = input.nextInt();

                            // validation checking for rows and seats
                            while (rowNum > 3 || rowNum < 1) {
                                System.out.println("Invalid row entered\n");
                                System.out.print("Enter the row number: ");
                                rowNum = input.nextInt();
                            }
                            while (true) {
                                System.out.print("Enter seat number   : ");
                                int SeatNum = input.nextInt();
                                if (SeatNum < 1 || SeatNum > Rows[rowNum - 1].length) {
                                    System.out.println("Invalid seat number");
                                } else if (Rows[rowNum - 1][SeatNum - 1] == 1) {
                                    System.out.println("Seat occupied! Please select another one.\n");
                                } else {
                                    // bought ticket represented by 1
                                    Rows[rowNum - 1][SeatNum - 1] = 1;
                                    // The ticket information defer depending on the number of tickets a user buys at once
                                    switch (numTickets) {
                                        case 1 -> {
                                            Ticket ticket = new Ticket(rowNum, SeatNum, 20.0, person,numTickets);
                                            tickets.add(ticket);
                                            availableNum =availableNum - 1;
                                            System.out.println("\nA reservation has been made for row " + rowNum + " seat " + SeatNum + ".\n");
                                        }
                                        case 2 -> {
                                            Ticket ticket2 = new Ticket(rowNum, SeatNum, 15.0, person,numTickets);
                                            tickets.add(ticket2);
                                            availableNum =availableNum - 1;
                                            System.out.println("\nA reservation has been made for row " + rowNum + " seat " + SeatNum + ".\n");
                                        }
                                        default -> {
                                            Ticket ticket3 = new Ticket(rowNum, SeatNum, 10.0, person,numTickets);
                                            tickets.add(ticket3);
                                            System.out.println(availableNum);
                                            availableNum =availableNum - 1;
                                            System.out.println("\nA reservation has been made for row " + rowNum + " seat " + SeatNum + ".\n");
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        break;
                    } else System.out.println("Number of tickets unavailable! Please try again.\n");
                } break;
            } catch (InputMismatchException e) {
                System.out.println("\nInvalid input! Please enter your detail again.\n");
            }
        }
    }
    public static void print_seating_area(int[] row1,int[] row2,int[] row3) {
        // printing a design of the theatre stage. O represents available seats and X represents occupied seats
        System.out.println("     ***********\n     *  STAGE  *\n     ***********");
        System.out.print("    ");
        for(int i = 0; i < row1.length; i++) {
            if(i==6) System.out.print(" ");
            if(row1[i] == 0) {
                System.out.print("O");
            } else {
                System.out.print("X");
            }
        }
        System.out.println();
        System.out.print("  ");
        for(int i = 0; i < row2.length; i++) {
            if(i==8) System.out.print(" ");

            if(row2[i] == 0) {
                System.out.print("O");
            } else {
                System.out.print("X");
            }
        }
        System.out.println();
        for(int i = 0; i < row3.length; i++) {
            if(i==10) System.out.print(" ");
            if(row3[i] == 0) {
                System.out.print("O");
            } else {
                System.out.print("X");
            }
        }System.out.println("\n");
    }
    public static void cancel_ticket(int[] row1, int[] row2, int[] row3, ArrayList<Ticket> tickets) {
        // Using exception handling to check invalid inputs
        while(true){
            try{ /// According to the number tickets the user enters the loop run and cancels tickets
                Scanner input = new Scanner(System.in);
                System.out.print("Number of tickets to cancel: ");
                int numTickets = input.nextInt();
                for (int i = 0; i < numTickets; i++) {
                    System.out.print("Enter the row number: ");
                    int rowNum = input.nextInt();
                    // validation checking for rows and seats
                    while (rowNum > 3 || rowNum < 1) {
                        System.out.println("Invalid row entered\n");
                        System.out.print("Enter the row number: ");
                        rowNum = input.nextInt();
                    }
                    while (true) {
                        System.out.print("Enter seat number   : ");
                        int SeatNum = input.nextInt();
                        int[][] Rows = {row1, row2, row3};
                        if (SeatNum < 1 || SeatNum > Rows[rowNum - 1].length) {
                            System.out.println("Invalid seat number");// if seats has not been booked and then ticket cannot be cancelled
                        } else if (Rows[rowNum - 1][SeatNum - 1] == 0) {
                            System.out.println("\nSeat is available.Cancellation unsuccessful\n");
                            break;
                        } else {
                            // canceled ticket are represented by 0
                            Rows[rowNum - 1][SeatNum - 1] = 0;
                            // remove ticket from ArrayList
                            for (int j = 0; j < tickets.size(); j++) {
                                if (tickets.get(j).getRow() == rowNum && tickets.get(j).getSeat() == SeatNum) {
                                    String emailCheck = tickets.get(j).getPerson().getEmail();
                                    tickets.remove(j);
                                    System.out.println("\nTicket for Row " + rowNum + " seat " + SeatNum + " has been canceled.\n");
                                    // The ticket prices get changed again according to the number of tickets bought
                                    for (int k = 0; k < tickets.size(); k++) {
                                        if (tickets.get(k).getPerson().getEmail().equals(emailCheck)) {
                                            if (tickets.get(k).getCount() == 3) tickets.get(k).setPrice(15);
                                            else tickets.get(k).setPrice(20);
                                        }
                                    }break;
                                }
                            }break;
                        }
                    }
                }break;
            } catch (InputMismatchException e){
                System.out.println("\nInvalid input! Please enter your detail again.\n");
            }
        }
    }
    public static void show_available(int[] row1,int[] row2,int[] row3){
        // In each array row the variable containing zero is printed
        // I have used an if statement to print a full stop after the last variable in the array
        System.out.print("Seats available in row 1: ");
        for (int i = 0; i < row1.length; i++) {
            if(row1[i]==0){
                System.out.print(i+1);
            }
            if(i==11)System.out.print(".\n");
            else System.out.print(",");
        }
        System.out.print("Seats available in row 2: ");
        for (int i = 0; i < row2.length; i++) {
            if(row2[i]==0){
                System.out.print(i+1);
            }
            if(i==15)System.out.print(".\n");
            else System.out.print(",");
        }
        System.out.print("Seats available in row 3: ");
        for (int i = 0; i < row3.length; i++) {
            if(row3[i]==0){
                System.out.print(i+1);
            }
            if(i==19)System.out.println(".\n");
            else System.out.print(",");
        }
    }
    public static void saveToFile(int[] row1, int[] row2, int[] row3){
        // I have passed the row arrays as one ragged array into the file
        // I have used try and catch block to see beware if there is an error or whether the file was created
        try {
           FileWriter fileWriter = new FileWriter("Theatre.txt");
            int[][] Rows = {row1, row2, row3};
            for (int[] row : Rows) {
                for (int i : row) {
                    fileWriter.write(i + " ");
                }
                fileWriter.write("\n");
            }
           fileWriter.close();
           System.out.println("The file has been saved.\n");
        }
        catch (IOException e)
        {
            System.out.println("\nAn error occurred.");
        }
    }
    public static void loadFromFile(int[]row1,int[]row2,int[]row3) {
        try { //Load from Theatre.txt from the last saved file.
            int[][] Rows = {row1, row2, row3};
            File file= new File("Theatre.txt");
            Scanner file_reader= new Scanner(file);
            for (int i = 0; i < Rows.length; i++) {
                for (int j = 0; j < Rows[i].length; j++) {  
                    Rows[i][j] = file_reader.nextInt();
                }
            }
            file_reader.close();
        }catch (FileNotFoundException e ){ // Checks if file exists
            System.out.println("\nError while reading the file.");
            System.out.println("Please ensure that you have saved your file before proceeding with the loading process");
        }
    }
    public static void show_tickets_info(ArrayList<Ticket> tickets) {
        double totalPrice = 0;
        // I have used a for loop to call each ticket in the ArrayList
        for(int i=0; i<tickets.size(); i++) {
            tickets.get(i).print();
            totalPrice += tickets.get(i).getPrice();
            System.out.println();
        }System.out.println("Total price: $" + totalPrice+"\n");
    }
    public static void sort_tickets(ArrayList<Ticket> tickets) {
        int n = tickets.size();
        // I am using bubble sort to sort the tickets from the cheapest price
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (tickets.get(j).getPrice() > tickets.get(j + 1).getPrice()) {
                    Ticket temp = tickets.get(j);
                    tickets.set(j, tickets.get(j + 1));
                    tickets.set(j + 1, temp);
                }
            }
        }
        System.out.println("\nSorted ticket list based on price:\n");
        for (Ticket ticket : tickets) {
            ticket.print();
            System.out.println();
        }
    }
}



